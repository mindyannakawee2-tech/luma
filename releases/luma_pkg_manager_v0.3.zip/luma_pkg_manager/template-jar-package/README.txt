Put your compiled Java app at:
ASSETS/bin/app.jar

Then pack with:
luma pack template-jar-package
