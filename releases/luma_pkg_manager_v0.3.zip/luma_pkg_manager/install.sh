#!/usr/bin/env bash
set -euo pipefail

PREFIX="${PREFIX:-/usr/local}"
BINDIR="$PREFIX/bin"
SELF_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

need_cmd() {
  command -v "$1" >/dev/null 2>&1 || return 1
}

pm_detect() {
  for pm in apt dnf zypper pacman apk xbps-install eopkg; do
    if need_cmd "$pm"; then echo "$pm"; return 0; fi
  done
  echo "unknown"
}

install_python_hint() {
  if need_cmd python3; then return 0; fi
  pm="$(pm_detect)"
  echo "Python 3 is required. Detected package manager: $pm"
  case "$pm" in
    apt) echo "Run: sudo apt update && sudo apt install -y python3" ;;
    dnf) echo "Run: sudo dnf install -y python3" ;;
    zypper) echo "Run: sudo zypper install -y python3" ;;
    pacman) echo "Run: sudo pacman -Sy --needed python" ;;
    apk) echo "Run: sudo apk add python3" ;;
    xbps-install) echo "Run: sudo xbps-install -S python3" ;;
    eopkg) echo "Run: sudo eopkg install python3" ;;
    *) echo "Install Python 3 using your distro package manager." ;;
  esac
  exit 1
}

install_python_hint

if [ "$(id -u)" -eq 0 ]; then
  install -d "$BINDIR"
  install -m 755 "$SELF_DIR/luma.py" "$BINDIR/luma"
else
  if command -v sudo >/dev/null 2>&1; then
    sudo install -d "$BINDIR"
    sudo install -m 755 "$SELF_DIR/luma.py" "$BINDIR/luma"
  else
    mkdir -p "$HOME/.local/bin"
    install -m 755 "$SELF_DIR/luma.py" "$HOME/.local/bin/luma"
    BINDIR="$HOME/.local/bin"
  fi
fi

echo "Installed LUMA to $BINDIR/luma"
echo "Try: luma --version"
echo "Check runtimes: luma doctor"
