#!/usr/bin/env bash
echo "LUMA app error: $1" >&2
exit 1
