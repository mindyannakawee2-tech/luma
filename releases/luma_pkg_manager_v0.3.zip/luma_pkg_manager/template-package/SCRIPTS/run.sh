#!/usr/bin/env bash
set -e
APP_DIR="$(cd "$(dirname "$0")/.." && pwd)"
python3 "$APP_DIR/ASSETS/src/main.py"
