#!/usr/bin/env bash
echo "LUMA app crashed: $1" >&2
exit 1
