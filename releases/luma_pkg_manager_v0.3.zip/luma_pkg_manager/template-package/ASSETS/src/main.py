#!/usr/bin/env python3
print("Hello from a .luma package!")
print("This app is running through the custom LUMA package manager.")
