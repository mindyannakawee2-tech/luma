#!/usr/bin/env bash
set -e
APP_DIR="$(cd "$(dirname "$0")/.." && pwd)"
java -jar "$APP_DIR/ASSETS/bin/app.jar"
