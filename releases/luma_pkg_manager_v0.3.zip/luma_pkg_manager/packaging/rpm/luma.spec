Name:           luma
Version:        0.3.0
Release:        1%{?dist}
Summary:        LUMA custom package manager for .luma apps
License:        MIT
BuildArch:      noarch
Requires:       python3

%description
LUMA installs and manages independent .luma packages and online repos.
This RPM only installs the LUMA CLI itself.

%prep

%build

%install
mkdir -p %{buildroot}/usr/bin
install -m 755 %{_sourcedir}/luma.py %{buildroot}/usr/bin/luma

%files
/usr/bin/luma

%changelog
* Sat Jul 11 2026 Auralis <auralis@example.local> - 0.3.0-1
- Initial RPM packaging skeleton
