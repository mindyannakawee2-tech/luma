#!/usr/bin/env bash
set -euo pipefail

VERSION="${VERSION:-0.3.0}"
ROOT="luma_${VERSION}_all"
rm -rf "$ROOT" "${ROOT}.deb"
mkdir -p "$ROOT/DEBIAN" "$ROOT/usr/bin" "$ROOT/usr/share/doc/luma"
install -m 755 ../../luma.py "$ROOT/usr/bin/luma"
cat > "$ROOT/DEBIAN/control" <<CTRL
Package: luma
Version: $VERSION
Section: utils
Priority: optional
Architecture: all
Depends: python3
Maintainer: Auralis <auralis@example.local>
Description: LUMA custom package manager for .luma apps
 LUMA installs and manages independent .luma packages and online repos.
CTRL
cat > "$ROOT/usr/share/doc/luma/README.Debian" <<'TXT'
LUMA is independent from APT/dpkg for app packages. This .deb only installs the luma CLI itself.
TXT
dpkg-deb --build "$ROOT"
echo "Built ${ROOT}.deb"
