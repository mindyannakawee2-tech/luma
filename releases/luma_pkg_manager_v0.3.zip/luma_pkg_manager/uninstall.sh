#!/usr/bin/env bash
set -euo pipefail

removed=0
for path in /usr/local/bin/luma /usr/bin/luma "$HOME/.local/bin/luma"; do
  if [ -f "$path" ]; then
    if [ -w "$(dirname "$path")" ]; then
      rm -f "$path"
    elif command -v sudo >/dev/null 2>&1; then
      sudo rm -f "$path"
    else
      echo "Need permission to remove $path"
      continue
    fi
    echo "Removed $path"
    removed=1
  fi
done

if [ "$removed" = 0 ]; then
  echo "No LUMA executable found in common locations."
fi

echo "User data is kept at:"
echo "  Linux: ~/.local/share/luma"
echo "  macOS: ~/Library/Application Support/LUMA"
echo "  Windows: %LOCALAPPDATA%\\LUMA"
