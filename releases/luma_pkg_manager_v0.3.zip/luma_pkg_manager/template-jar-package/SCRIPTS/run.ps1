$AppDir = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
java -jar "$AppDir\ASSETS\bin\app.jar"
