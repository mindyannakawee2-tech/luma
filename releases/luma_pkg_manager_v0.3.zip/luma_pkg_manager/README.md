# LUMA Package Manager v0.3

Custom package manager starter for `.luma` packages.

This is **not** APT, dpkg, Flatpak, or a Flatpak wrapper. LUMA uses its own `.luma` package format and can install apps from online static repos such as GitHub Pages.

The distro package manager is only used to install the **LUMA CLI itself**. LUMA apps still use `.luma`, not `.deb`, `.rpm`, or Flatpak.


## Install LUMA itself on any distro

### Local install from this folder

```bash
cd luma_pkg_manager
sudo ./install.sh
```

The installer checks for Python 3 and detects common package managers:

```text
apt, dnf, zypper, pacman, apk, xbps-install, eopkg
```

### Online install from GitHub Pages

Put `luma.py` and `install-online.sh` on GitHub Pages, then run:

```bash
curl -fsSL https://USERNAME.github.io/luma-site/install-online.sh | LUMA_BASE_URL=https://USERNAME.github.io/luma-site bash
```

Or with wget:

```bash
wget -qO- https://USERNAME.github.io/luma-site/install-online.sh | LUMA_BASE_URL=https://USERNAME.github.io/luma-site bash
```

### Native distro package skeletons

Included starter packaging files:

```text
packaging
├── deb
│   └── build-deb.sh
├── rpm
│   └── luma.spec
├── arch
│   └── PKGBUILD
└── homebrew
    └── luma.rb
```

Build a `.deb` locally:

```bash
cd packaging/deb
./build-deb.sh
sudo apt install ./luma_0.3.0_all.deb
```

Check LUMA and runtimes:

```bash
luma doctor
```


Or run without installing:

```bash
python3 luma.py --version
```

## Basic commands

```bash
luma create-template hello-luma-package
luma pack hello-luma-package
luma install org.auralis.hello_1.0.0.luma
luma list
luma info org.auralis.hello
luma run org.auralis.hello
luma remove org.auralis.hello
```

## Online repo commands

Add a repo from GitHub Pages or any static web host:

```bash
luma install pkg-get https://username.github.io/smth
```

That URL must contain:

```text
https://username.github.io/smth/packages.json
```

Then search and install apps:

```bash
luma search hello
luma install org.auralis.hello
```

You can also add/refresh a repo with the shorter command:

```bash
luma pkg-get https://username.github.io/smth
```

Or add repo and install an app in one command:

```bash
luma install pkg-get https://username.github.io/smth org.auralis.hello
```

Direct `.luma` URL install also works:

```bash
luma install https://username.github.io/smth/packages/org.auralis.hello_1.0.0.luma
```

Repo management:

```bash
luma repo list
luma repo refresh
```

Generate `packages.json` automatically for your own repo folder:

```bash
mkdir -p my-luma-repo/packages
cp org.auralis.hello_1.0.0.luma my-luma-repo/packages/
luma make-repo my-luma-repo --name my-repo
```

## Repo layout

Upload this folder structure to GitHub Pages:

```text
repo-root
├── packages.json
├── packages
│   └── org.auralis.hello_1.0.0.luma
└── icons
    └── org.auralis.hello.png
```

Example `packages.json`:

```json
{
  "repo_format": "luma-repo-v1",
  "name": "auralis-sample",
  "description": "Sample LUMA repository.",
  "packages": [
    {
      "app_id": "org.auralis.hello",
      "name": "LUMA Hello",
      "version": "1.0.0",
      "description": "Example app for testing online LUMA install.",
      "category": "Utility",
      "file": "packages/org.auralis.hello_1.0.0.luma",
      "icon": "icons/org.auralis.hello.png",
      "sha256": "PUT_SHA256_HERE"
    }
  ]
}
```

Generate SHA256 on Linux:

```bash
sha256sum packages/org.auralis.hello_1.0.0.luma
```

## Package layout

```text
package.luma
├── MANIFEST
│   ├── config.txt
│   └── icon.png
├── SCRIPTS
│   ├── run.sh
│   ├── run.ps1
│   ├── error_handler.sh
│   ├── error_handler.ps1
│   ├── crash_handler.sh
│   └── crash_handler.ps1
└── ASSETS
    ├── src
    │   └── main.*
    ├── assets
    └── bin
        ├── linux
        ├── windows
        └── macos
```

## Manifest example

```ini
APP_ID=org.auralis.hello
APP_NAME=LUMA Hello
VERSION=1.0.0
AUTHOR=Auralis
TYPE=python
MAIN=ASSETS/src/main.py
ICON=MANIFEST/icon.png
LINUX_RUN=SCRIPTS/run.sh
MACOS_RUN=SCRIPTS/run.sh
WINDOWS_RUN=SCRIPTS/run.ps1
CATEGORY=Utility
DESCRIPTION=Example LUMA package.
```

## Current data root

Linux:

```text
~/.local/share/luma
```

macOS:

```text
~/Library/Application Support/LUMA
```

Windows:

```text
%LOCALAPPDATA%\LUMA
```

Override it:

```bash
export LUMA_ROOT="$HOME/test-luma-root"
```
