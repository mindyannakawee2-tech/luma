$AppDir = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
python "$AppDir\ASSETS\src\main.py"
