# GitHub Pages LUMA installer layout

Upload these files to your GitHub Pages repo:

```text
luma-site
├── luma.py
├── install-online.sh
├── packages.json          # optional app repo index
└── packages               # optional .luma packages
```

Then install LUMA with:

```bash
curl -fsSL https://USERNAME.github.io/luma-site/install-online.sh | LUMA_BASE_URL=https://USERNAME.github.io/luma-site bash
```

Or with wget:

```bash
wget -qO- https://USERNAME.github.io/luma-site/install-online.sh | LUMA_BASE_URL=https://USERNAME.github.io/luma-site bash
```
