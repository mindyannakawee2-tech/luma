class Luma < Formula
  desc "LUMA custom package manager for .luma apps"
  homepage "https://example.local/luma"
  url "https://example.local/luma/luma.py"
  version "0.3.0"
  sha256 :no_check

  depends_on "python@3"

  def install
    bin.install "luma.py" => "luma"
  end
end
